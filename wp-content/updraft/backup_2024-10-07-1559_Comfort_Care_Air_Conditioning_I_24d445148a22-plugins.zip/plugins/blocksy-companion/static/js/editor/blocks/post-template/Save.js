import { createElement } from '@wordpress/element'

import { InnerBlocks } from '@wordpress/block-editor'

const Save = () => {
	return <InnerBlocks.Content />
}

export default Save
