<?php

$config = [
	'name' => __('Widget Area 2', 'blocksy')
];



