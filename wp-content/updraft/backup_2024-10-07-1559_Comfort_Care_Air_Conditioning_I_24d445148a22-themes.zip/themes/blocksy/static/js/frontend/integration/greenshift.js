export const mount = () => {
	if (window.gsInitTabs) {
		window.gsInitTabs('.gspb-tabs')
	}
}
