/**
 * Internal dependencies
 */
import './move-to-sidebar'
